@@InstallOracleASPNETCommon.sql
@@InstallOracleMembership.sql
@@InstallOraclePersonalization.sql
@@InstallOracleProfile.sql
@@InstallOracleRoles.sql
@@InstallOracleSiteMap.sql
@@InstallOracleWebEvents.sql
@@InstallOracleSessionState.sql
